package es.urjc.etsii.grafo.testutil;

import es.urjc.etsii.grafo.io.Instance;

public class TestInstance extends Instance {
    public TestInstance(String name) {
        super(name);
    }
}
