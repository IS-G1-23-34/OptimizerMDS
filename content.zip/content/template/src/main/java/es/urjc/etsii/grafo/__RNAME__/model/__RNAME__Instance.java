package es.urjc.etsii.grafo.__RNAME__.model;

import es.urjc.etsii.grafo.io.Instance;

public class __RNAME__Instance extends Instance {

    public __RNAME__Instance(String name){
        super(name);
        // TODO Add all required fields and parameters
    }


    // compareTo may be overriden to specify a custom instance solving order (default ordering by instance file name)
}
