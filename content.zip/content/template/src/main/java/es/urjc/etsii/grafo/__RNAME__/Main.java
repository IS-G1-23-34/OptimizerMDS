package es.urjc.etsii.grafo.__RNAME__;

import es.urjc.etsii.grafo.solver.Mork;

public class Main {
    public static void main(String[] args) {
        Mork.start(args);
    }
}
